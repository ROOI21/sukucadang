<<$ring>> terminal ring
<<$clear>> clear screen 

----------------------------------------

<<$uptime>> timesince started
<<$os>> Server OS
<<$arch>> Server Cpu arch "x86" the binary is compiled for x86 already

-----------------------------------------

<<$username>> username for session
<<$concurrents>> allowed concurrent attacks for session
<<$timelimit>> allowed max attack time for session
<<$credits>> credits in cnc store
<<$cooldown>> cooldown between attacks for session
<<$remoteaddress>> connected address for session
<<$remoteclient>> SSH client for session
<<$roles>> roles array

<<$vip>> vip boolean
<<$reseller>> reseller boolean
<<$admin>> admin boolean
<<$banned>> banned boolean
<<$api>> api acess boolean

<<$expiry>> expiry rounded the the nearest unit of measurement i.e 100 days(s)
<<$expirydate>> expiry as date 2022-05-20
<<$expirydays>> expiry as the number of day

-----------------------------------------

<<$ongoing>> ongoing attacks for session
<<$onlineusers>> open sessions for server
<<$allgoing>> all running attacks for server
<<$allattacks>> total attacks for server "mysql"
<<$totalusers>> total users in database

-----------------------------------------

<<sleep(Int)>> sleep for int
<<include(File String)>>

-----------------------------------------

<<$spinner>> spinner for title only

-----------------------------------------

<<ansi(LINK)>> Paid Gif DLC
<<ascii(LINK)>> Paid Gif DLC
<<braille(LINK)>> Paid Gif DLC

-----------------------------------------

<<$delay>> delay of attack in attack asset
<<$host>> Display attacked host where applicable  
<<$port>> Display attacked port where applicable  
<<$time>> Display duration of attack where applicable  
<<$method>> Display method of attack where applicable

-----------------------------------------

<<$botcount>> Shows all connected devices including fakecount devices

-----------------------------------------

<<$date>> date using users timezone
<<$timenow>> current time (1:00pm)
<<$timezone>> Timezone of user
